<?php
$dir=__DIR__;

?>